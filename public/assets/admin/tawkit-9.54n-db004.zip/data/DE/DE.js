var JS_CITIES_DATA =
[
"DE.friedrichshafen.",
"DE.KEHI.",
"DE.KIEL.",
"DE.KIEL2.",
"DE.Osnabrueck.",
"DE.PAPENBURG.",
"DE.Ravensburg.",
];